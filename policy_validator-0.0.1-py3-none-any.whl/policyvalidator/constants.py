import boto3

sts_client = boto3.client('sts')
response = sts_client.get_caller_identity()
my_account_number = response['Account']

class bcolors:
	OKGREEN = '\033[92m'
	BLUE = '\033[94m'
	WARNING = '\033[93m'
	FAIL = '\033[91m'
	END = '\033[0m'
	BOLD = '\033[1m'

resource_name = "my-bucket"
all_resource = "*"
source_vpc = "vpc-12345678"
principal_account = "123456789999"
orgid = "org-1234"
resourceorgid = "org-1234"
corporatecidr = "10.0.0.0/16"
valid_resource_name = "arn:aws:s3:::my-bucket/*"

class ValidationException(Exception):
	def __init__(self, message):
		message = f'{bcolors.FAIL}ERROR: {message}{bcolors.END}'
		super().__init__(message)
		
