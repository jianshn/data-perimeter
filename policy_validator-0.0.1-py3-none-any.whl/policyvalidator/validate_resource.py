import boto3
import json
import constants
from constants import ValidationException, bcolors

def validate_perimeter_on_resources(policy_as_json, scenario, type):
	if scenario == 1:
		validate_scenario_1(policy_as_json)
	if scenario == 2:
		validate_scenario_2(policy_as_json, type)
	if scenario == 3:
		validate_scenario_3(policy_as_json, type)

def validate_scenario_1(policy_as_json):
	statements = __get_statements(policy_as_json)

	for index, statement in enumerate(statements):
		resources = statement.get('Resource')
		if resources is None:
			raise ValidationException(f'Statement {index + 1} is missing Resource element.')

		resources = resources if isinstance(resources, list) else [resources]
		if all([resource != constants.valid_resource_name for resource in resources]):
			raise ValidationException(
				f'At least one value in the Resource element must be {constants.valid_resource_name}. Found missing in statement {index + 1}.')
		
		Effect = statement.get("Effect")
		if Effect == "Allow":
			raise ValidationException('Deny effect is preferred')
		
		Condition = statement.get("Condition")
		if Condition["StringNotEqualsIfExists"]["aws:SourceVpc"] != constants.source_vpc or Condition["StringNotEqualsIfExists"]["aws:PrincipalOrgID"] != constants.orgid:
			raise ValidationException('Policy is missing or contains invalid source vpc and/or Principal Organisation ID')

def validate_scenario_2(policy_as_json, type):
	statements = __get_statements(policy_as_json)

	for index, statement in enumerate(statements):
		resources = statement.get('Resource')
		if resources is None:
			raise ValidationException(f'Statement {index + 1} is missing Resource element.')

		resources = resources if isinstance(resources, list) else [resources]
		if all([resource != constants.valid_resource_name for resource in resources]):
			raise ValidationException(
				f'At least one value in the Resource element must be {constants.valid_resource_name}. Found missing in statement {index + 1}.')
		
		Effect = statement.get("Effect")
		if Effect == "Allow":
			raise ValidationException('Deny effect is preferred')
		
		Condition = statement.get("Condition")

		if type == 'scp':
			if Condition["StringNotEqualsIfExists"]["aws:SourceVpc"] != constants.source_vpc:
				raise ValidationException('Policy is missing or contains invalid source vpc')
			if Condition["BoolIfExists"]["aws:ViaAWSService"] != 'false':
				raise ValidationException('Ensure non AWS service requests are rejected')
			try:
				if not Condition["StringEquals"]["aws:PrincipalTag/data-perimeter-include"]:
					print(f'\033[93mPolicy is correct but might cause failures if pushed into production. Add a tag to only include certain resources in data perimeter')
				elif Condition["StringEquals"]["aws:PrincipalTag/data-perimeter-include"] != 'true':
					print(f'\033[93m Warning: Tag is present, check that your boolean is correct.')
			except Exception as e:
				print(e)
		
		if type == 'rp':
			if Condition["StringNotEqualsIfExists"]["aws:SourceVpc"] != constants.source_vpc:
				raise ValidationException('Policy is missing or contains invalid source vpc')
			if Condition["BoolIfExists"]["aws:ViaAWSService"] != 'false' or Condition["BoolIfExists"]["aws:PrincipalIsAWSService"] != 'false':
				raise ValidationException('Only allow requests made by an AWS service and a principal on behalf of an AWS service to your resource.')

def validate_scenario_3(policy_as_json, type):
	statements = __get_statements(policy_as_json)

	for index, statement in enumerate(statements):
		resources = statement.get('Resource')
		if resources is None:
			raise ValidationException(f'Statement {index + 1} is missing Resource element.')

		resources = resources if isinstance(resources, list) else [resources]
		if all([resource != constants.all_resource for resource in resources]):
			raise ValidationException(
				f'No restrictions on connections to AWS resources through VPC endpoint.')
		
		Condition = statement.get("Condition")
		
		if type == 'vpcep':
			Effect = statement.get("Effect")
			if Effect == "Deny":
				raise ValidationException('Allow effect is preferred')
			if Condition["StringEquals"]["aws:PrincipalOrgID"] != constants.orgid:
				raise ValidationException('Policy is missing or contains invalid principal org id')
			if Condition["StringEquals"]["aws:ResourceOrgID"] != constants.resourceorgid:
				raise ValidationException('Policy is missing or contains invalid resource org id')
		
		if type == 'scp':
			Effect = statement.get("Effect")
			if Effect == "Allow":
				raise ValidationException('Deny effect is preferred')
			if Condition["StringNotEqualsIfExists"]["aws:ResourceOrgID"] != constants.resourceorgid:
				raise ValidationException('Policy is missing or contains invalid resource org id')

def __get_statements(policy_as_json):
	statements = policy_as_json.get('Statement')
	if statements is None:
		raise ValidationException('Policy is missing statement element.')

	return statements

def validate_iam_policy(policy_as_json, scenario, type):
	client = boto3.client("accessanalyzer")
	paginator = client.get_paginator("validate_policy")
	policy = ''

	if scenario == 1 and type == 'rp':
		policy = 'RESOURCE_POLICY'
	elif scenario == 2 and type == 'scp':
		policy = 'SERVICE_CONTROL_POLICY'
	elif scenario == 2 and type == 'rp':
		policy = 'RESOURCE_POLICY'
	elif scenario == 3 and type == 'vpcep':
		policy = 'RESOURCE_POLICY'
	elif scenario == 3 and type == 'scp':
		policy = 'SERVICE_CONTROL_POLICY'
	else:
		raise ValidationException(f"Wrong policy type for scenario {scenario}")

	response_iterator = paginator.paginate(
		policyDocument=json.dumps(policy_as_json),
		policyType=policy
	)

	error_findings = []
	for response in response_iterator:
		error_findings.extend([finding for finding in response['findings'] if finding['findingType'] == 'ERROR'])

	if len(error_findings) > 0:
			message = f'{bcolors.FAIL}Policy failed validation.'
			for finding in error_findings:
				message = message + f'\n\t{finding["findingDetails"]}'

			message = message + bcolors.END

			raise ValidationException(message)
	else:
		print("\033[92mPolicy is valid!")