import json
import sys
import argparse
import traceback

import validate_resource, constants
from constants import ValidationException, bcolors
from version import __version__

def main(args=None):
    if args is None:
        args = sys.argv[1:]

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--version', action='version', version='%(prog)s ' + __version__)
    parser.add_argument('--policy', metavar="POLICY", dest="policy", required=True, help='The path to the IAM policy to evaluate.')
    parser.add_argument('--scenario', metavar="SCENARIO", dest="scenario", required=True, type=int, help='The scenario of the workshop you are working on.')
    parser.add_argument('--type', metavar="TYPE", dest="type", required=True, choices=['scp', 'rp', 'vpcep'], type=str, help='The policy type you are working on.')
    args = parser.parse_args(args)

    try:
        with open(args.policy) as f:
            try:
                policy = json.load(f)
            except ValueError as e:
                raise ValidationException(f'Policy contains invalid JSON.  {str(e)}')

        print(f'{bcolors.BLUE}Running checks for Policy file: {args.policy}{bcolors.END}\n')

        validate_resource.validate_perimeter_on_resources(policy, args.scenario, args.type)
        validate_resource.validate_iam_policy(policy, args.scenario, args.type)

    except ValidationException as e:
        print(str(e))
        exit(1)
    except Exception as e:
        traceback.print_exc()
        print(f'ERROR: Unexpected error occurred. {str(e)}', file=sys.stderr)
        exit(1)


if __name__ == "__main__":
    main()